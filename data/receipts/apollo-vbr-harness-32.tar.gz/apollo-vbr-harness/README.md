# Apollo VBR test harness — for review

Everything used to produce the VBR fidelity result, plus the layer-pricing band that is still
running. Sent because the codec's author asked to review the method. Please break it.

**Disclosure:** Mark collaborates with buun. The method was pre-registered and the unfavourable
outcome was named before the data existed. The headline prediction **failed**, and is reported
as failed.

## What is in here

| path | what |
|---|---|
| `fidelity/PREREG_VBR_FIDELITY.md` | pre-registration, written before the data |
| `fidelity/RESULT_VBR_FIDELITY.md` | the result, incl. what it does NOT establish |
| `fidelity/vbr_fid.sh` | **exact server launch flags per arm** |
| `fidelity/order_q27_rev.txt` | the reversed `VBR_DEGRADE_ORDER` used for the control |
| `fidelity/run_arm.py` | fill-to-bitrate, verify achieved `kv_bpv`, then measure |
| `fidelity/fid_*.jsonl` | raw per-item results, one line per item, written with fsync |
| `fidelity/arm_*.log` | per-arm achieved bpv, liveness, tallies |
| `corpus/` | the calibration items and the runner |
| `layer-pricing/` | fp16→t8 per-(layer,side) band — **in progress, see below** |

## The fidelity result in one table

All arms at matched context depth (~29k), `Qwen3.8-27B-UD-IQ4_XS`, 3 seeds × 16 items = 48
cells/arm, `reasoning_effort` pinned to `medium`.

| arm | KV bytes | achieved bpv | confab | abstain | acc | t/s |
|---|---:|---:|---:|---:|---:|---:|
| `F16` | 1,824 MiB | 16.0 | 1/24 | 23/24 | 24/24 | 13.83 |
| `CBR325` `turbo3_tcq` | 370 MiB | 3.25 | 1/24 | 23/24 | 24/24 | 8.61 |
| `VBR416` `--vbr-floor t1 --vbr-vram 416M` | 371 MiB | 3.254 | 0/24 | 24/24 | 24/24 | 9.07 |
| `VBR416R` same budget, reversed order | 371 MiB | 2.172 | 1/24 | 23/24 | 24/24 | 9.74 |

1. **4.9× KV compression costs nothing measurable here.** 370 MiB vs 1,824 MiB, calibration
   within one item.
2. **The registered prediction failed.** VBR was predicted to beat CBR at matched bytes
   (registered at 0.50). It did not — one item apart is noise at n=24.
3. **The price table does real work on a different axis.** Same 416 MiB: correct order reaches
   3.254 bpv aggregate, reversed reaches 2.172 — **33 % worse from identical bytes**. It buys
   bits-per-byte, which is what a price-ordered water-fill is supposed to do.

## Where we think this is weakest — start here

- **16 items is a gate, not a measurement.** Every arm landed within one item of every other.
  The instrument has a sensitivity floor and a tie is **not** evidence of no difference. If the
  objection is "this can't detect what you claim it detects" — agreed, and stated in the result.
- **The reversed-order control is not clean.** The source says a custom `VBR_DEGRADE_ORDER`
  "carries no band guarantee, so it disables demand shedding", so `VBR416R` differs from
  `VBR416` in more than ordering. The 33 % number inherits that. A cleaner control would help
  and we don't know how to build one without a code change.
- **`Qwen3.8` runs the `q27` table generated for `Qwen3.6`.** Never scanned. Given that
  reversing the order matters, this is a live confound in every VBR arm above.
- **One model, one quant, one arch, one depth.** No claim beyond that envelope.
- **`realized_bpv` is null in dynamic mode**, so achieved bitrate is read from the server log
  and `/props` is not trusted (it misreported `floor_bpv` — passed `t2`, reported `4.125`,
  log said `2.25`).

## layer-pricing — in progress, and the interim conclusion is negative

Measuring a per-(layer, side) price for the fp16→t8 transition, one-step `VBR_DEGRADE_ORDER`
per cell, 16 KV layers × 2 sides. **Read `INTERIM_BAND.md` before the numbers** — two things
matter:

1. **The null is not zero.** `anchor_selfcheck.bin` is fp16 vs the fp16 base, where true KLD is
   exactly zero at every position. Measured: ±7e-5, **50.6 % negative**. That is GPU run-to-run
   nondeterminism. Per-position KLD is unusable at this signal size.
2. **A first pass got this wrong and is corrected in the file.** It applied the *null's* SE
   (7.8e-08) to the cells and reported "12/12 clear at z = 9–28". A cell also carries
   chunk-dependent quantization variance; on its own SE (median 6.1e-07, **7.9× noisier**) it is
   7/12. The corrected conclusion: `rho_half` ≈ 0.46 against a 0.90 bar, median adjacent gap
   0.15 cell-SE, and closing that would take **~839 h for 32 cells**. The per-(layer,side)
   price is **not obtainable at reasonable cost with this instrument.**
3. **What survives is worth more than the table was.** K > V at the layer level:
   **t = 6.65 on 14 df, p < 0.0001, sign 15/15** — every layer measured is K-costlier. If that
   holds at other transitions and models, an allocator may need a **K/V asymmetry constant, not
   a scan**. Stated as a hypothesis from one model at one transition, not a result.

`analyze_band.py` regenerates all of it from the `.bin` files (needs numpy + scipy):

```
cd layer-pricing && python analyze_band.py .
```

**31 of 32 cells** at time of packing; the last was still running. The analyzer prints the
cell count it used, so re-running on a later drop is self-describing.

## Note on the corpus

`corpus/fixture_v0_beta.json` contains the actual calibration items. Its validity depends on
the items not being trained on or widely circulated — treat accordingly. The raw `fid_*.jsonl`
deliberately store IDs and short answers only, never question text.
