# Environment

## Hardware — `.194`, all VBR work ran here

- 2× Tesla P100 16 GB (sm_60), GPUs **0 and 1**, on **NUMA node 0**, `PHB` between them.
  (The box has 4 P100s; 2+3 sit on node 1 and are `SYS` across. Pairs are not interchangeable.)
- 2× Xeon E5-2650 v3, 64 GB DDR4-2133 ECC.
- **Clocks pinned: 1063 MHz application clock, 150 W limit**, on every GPU, for every run here.
  Not stock autoboost. Any t/s number in this harness is at that state.
- `GGML_CUDA_ALLREDUCE=internal` exported for all tensor-split work.
- Arms are launched under `numactl --cpunodebind=0 --membind=0` with `CUDA_VISIBLE_DEVICES=0,1`.

## Build

buun-llama-cpp **`7d30a7244`** ("hip: gate sparse K == V path on thread geometry"),
`build_sm60_new`, binary dated Aug 22 19:13. Includes the sm_60 routing fix.

## Model

`Qwen3.8-27B-UD-IQ4_XS.gguf`. `qwen35` arch, 65 blocks (blk.64 is the MTP head), **16 full-attn
KV layers** — which is why the band is 16 layers × 2 sides = 32 cells, and why the degrade-order
files index layers 3, 7, 11 … 63. 65,536 B/token at f16.

## Server flags

Per arm, verbatim, in `fidelity/vbr_fid.sh`. Common to all:
`-ngl 99 -c 32768 -np 1 -sm tensor -fit off`.

`-fit off` is mandatory on Pascal — these cards fault under row-splitting.

## Sampling

Card sampling: `temperature 1.0, top_p 0.95, top_k 20`. `n_predict` per the fixture.

**`reasoning_effort` is pinned to `medium`.** This matters more than it looks: on Qwen3.8 the
setting is a *prompt edit*, not a sampling knob. Unset resolves to `xhigh`, which injects a
207-character block, costs ~5.85× the tokens, and destabilises the unanswerable arm — an earlier
pass with it unpinned produced 7 non-terminating generations, all on the unanswerable side, and
was discarded (`fid_F16_xhigh_DISCARD.jsonl` is kept in the tarball as the discarded evidence).
`medium` injects nothing and is the unmodified model.

## Measurement conventions

- Achieved bitrate is read from the **server log**, never `/props`, which misreported
  `floor_bpv` (passed `t2`, reported `4.125`, log said `2.25`).
- `realized_bpv` is **null in dynamic VBR by design** (`server-context.cpp:15205`). It reads like
  a disengaged controller and is not.
- Every long run writes per item with flush + fsync. Standing rule after losing a run to a power
  event; the raw `.jsonl` are append-per-item for that reason.
- Chunks, not positions, are the independent unit in the KLD band — positions inside a chunk
  share a KV history.
