#!/usr/bin/env bash
# VBR fidelity, matched on ACHIEVED bitrate. See PREREG_VBR_FIDELITY.md.
set -u
B=~/buun-llama-cpp/build_sm60_new/bin/llama-server
M=~/AI/Models/Qwen3.8-27B/Qwen3.8-27B-UD-IQ4_XS.gguf
export GGML_CUDA_ALLREDUCE=internal
PORT=8100

# arm <label> <extra server args...>
arm () {
  local label="$1"; shift
  echo "######## $label  $(date -Iseconds)"
  CUDA_VISIBLE_DEVICES=0,1 numactl --cpunodebind=0 --membind=0 \
    $B -m $M -ngl 99 -c 32768 -np 1 -sm tensor -fit off "$@" \
    --host 0.0.0.0 --port $PORT > /tmp/fid_$label.log 2>&1 &
  SRV=$!; R=0
  for i in $(seq 1 120); do
    [ "$(curl -s -o /dev/null -w %{http_code} http://127.0.0.1:$PORT/health 2>/dev/null)" = "200" ] && { R=1; break; }
    kill -0 $SRV 2>/dev/null || { echo "  DIED: $(grep -oiE 'out of memory|CUDA error|failed [a-z ]*' /tmp/fid_$label.log|tail -1)"; break; }
    sleep 3
  done
  if [ "$R" = 1 ]; then
    grep -oE "VBR dynamic runtime controller:.*" /tmp/fid_$label.log | head -1 | sed 's/^/  /'
    echo "  ARM_READY $label"
  else
    echo "  ARM_FAILED $label"
  fi
}

case "${1:-}" in
  f16)   arm F16   -ctk f16 -ctv f16 ;;
  s325)  arm S325  -ctk turbo3_tcq -ctv turbo3_tcq ;;
  q40)   arm Q40   -ctk q4_0 -ctv q4_0 ;;
  v325)  arm V325  -ct vbr --vbr-floor 3.25 --vbr-vram 256M ;;
  v6)    arm V6    -ct vbr --vbr-floor 6    --vbr-vram 256M ;;
  vbr416)  arm VBR416  -ct vbr --vbr-floor t1 --vbr-vram 416M ;;
  vbr416r) export VBR_DEGRADE_ORDER=/tmp/order_q27_rev.txt
           arm VBR416R -ct vbr --vbr-floor t1 --vbr-vram 416M ;;
  *) echo "usage: $0 {f16|s325|q40|v325|v6}"; exit 1 ;;
esac
