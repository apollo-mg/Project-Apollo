# fp16->t8 layer-pricing band — 31 of 32 cells

Qwen3.8-27B UD-IQ4_XS | .194 GPU0+1 (NUMA node 0) | buun `e332b24` build_sm60_new
`-c 4096 --chunks 8 -sm tensor -fit off -ct vbr --vbr-floor t8 --vbr-vram 64M`
`GGML_CUDA_ALLREDUCE=internal` | 1063 MHz / 150 W | base = `base_f16.dat`

Each cell = one-step `VBR_DEGRADE_ORDER` demoting exactly one (layer, side) to t8,
byte-identical to the anchor otherwise. Layers 3,7,...,63 x {k,v} = 32 cells.

**Envelope:** `first=2048`, so every scored position sits at **2–4k of KV depth**. This is a
shallow-context table. Our own VBR fidelity run showed depth changes behaviour (f16
confabulation 3/24 → 1/24 going from 0 to 29k), so nothing here extends to long context (AFM-24).

## The null is not zero — and it had to be measured, not assumed

`anchor_selfcheck.bin` is fp16 vs the fp16 base. True KLD is **exactly zero** at every
position. Measured: mean -1.200e-07, median -4.157e-10, range -7.13e-05 … +6.10e-05,
**50.6% negative**. Cells show the same 48.9% negative fraction and the same -7.2e-05 floor.

This is GPU run-to-run nondeterminism (reduction order / atomics), not estimator error:

- **Per-position KLD values are unusable here.** The signal (~1e-6 mean) is ~70x smaller than
  one position's noise. Only chunk-level aggregates survive.
- Any metric touching the tail is invalid: `trim99` returned a *negative* mean and `log1p`
  went NaN, both purely from noise.

## The SE trap — this inverted the headline

There are two different SEs and using the wrong one inflates every z-score ~8x:

| | SE of the 8-chunk mean |
|---|---|
| null (GPU nondeterminism only) | 7.8e-08 |
| **median cell** (also carries chunk-dependent quantization variance) | **6.1e-07** |

Cells are **7.9x noisier than the null**. A first pass here applied the null's SE to the
cells and reported "12/12 clear at z = 9.4–27.8". That was wrong. Corrected below.

## [1] The price is real but weak — 21/31

Against each cell's **own** SE, 21 of 31 clear the null individually at 95%. Means span
5.59e-07 to 1.89e-06.

## [2] K costs more than V — and this is the finding

The layer is the replication unit: the same 8 text chunks recur in every layer, so treating
15 layers x 8 chunks as 120 independent deltas is pseudoreplication. At the layer level:

**mean K-V = +5.310e-07, t = 6.65 on 14 df, p < 0.0001, sign 15/15**

Every single layer measured is K-costlier. At 6 layers this was p=0.011 and looked suggestive;
at 15 it is unambiguous.

## [3] The fine price table is not obtainable — gate FAILS, harder

**`rho_half` = 0.569 +/- 0.093 over all 35 distinct 4/4 chunk splits, range [0.365, 0.718].**
Gate **0.90**, stated here because no threshold is recorded in METHODOLOGY
(`OUTLINE_lowbit_methodology.md` is an article outline and has no §6).

Median adjacent gap is **0.15 cell-SE** — *smaller* than at 12 cells, because more cells pack
into the same range. Closing it to 3 SE needs ~3070 chunks/cell: **~26 h per cell, ~839 h for
32 cells.** The fp16->t8 per-(layer,side) price is **not obtainable at any reasonable cost on
this instrument.**

## What this means practically

The two results together are more useful than the price table would have been. A per-cell
scan is unaffordable, but the structure it would have revealed at this transition appears to
be **one bit of information, not 32**: the K side is uniformly more expensive than the V side.

If that holds at other transitions and on other models, an allocator does not need a scan --
it needs a K/V asymmetry constant. That would make "auto-generate a table on encountering an
unknown model" cheap, just not in the form originally imagined. **This is a hypothesis from
one model at one transition, not a result.** The test is the next experiment below.

## Standing

The next experiment is **not more chunks**. It is the same band at a *large* transition
(fp16->t4 or t2), where effect/noise is far better, asking two questions:

1. is the ranking **transition-invariant**? If yes, a table comes cheap from one big transition.
2. does **K > V** hold there too, and at what ratio?

If the fine ranking is not transition-invariant and K>V is all that survives, then "a layer
price table" was never a coherent object at this granularity -- and that is the finding.

Analyzer: `analyze_band.py`.
